# CSV → HTML Auto-Renderer

Push a CSV. All your HTML pages auto-render with the latest data.

## Folder Structure

```
your-repo/
├── data/
│   └── products.csv          ← Your single CSV (update this)
├── templates/
│   ├── catalog.html           ← Your designed HTML pages
│   ├── dashboard.html         ← (as many as you want)
│   └── report.html
├── assets/
│   ├── style.css              ← Your CSS
│   ├── script.js              ← Your JS
│   └── images/                ← Any images
├── build.py                   ← The renderer (don't edit)
├── .github/workflows/
│   └── render.yml             ← GitHub Action (don't edit)
└── output/                    ← Auto-generated (don't edit)
```

## How to Use

### 1. Set up your templates

In your HTML files inside `templates/`, add **`data-csv-repeat`** to any element
that should repeat for every row in the CSV:

```html
<div class="card" data-csv-repeat>
  <h2>{{name}}</h2>
  <p>{{description}}</p>
  <span>${{price}}</span>
</div>
```

### 2. Use `{{column_name}}` placeholders

These match your CSV column headers exactly. For a CSV with columns
`name,price,category`, use `{{name}}`, `{{price}}`, `{{category}}`.

### 3. Built-in placeholders (work anywhere)

| Placeholder | Value |
|---|---|
| `{{__total_rows__}}` | Number of data rows |
| `{{__generated_at__}}` | Timestamp of last build |
| `{{__index__}}` | 0-based row index (inside repeat only) |
| `{{__number__}}` | 1-based row number (inside repeat only) |

### 4. Push your CSV

Update `data/products.csv` and push. The GitHub Action will:
1. Read your CSV
2. Render every template in `templates/`
3. Deploy to GitHub Pages

### 5. Enable GitHub Pages

Go to **Settings → Pages → Source** → set to `gh-pages` branch.

Your pages will be live at `https://yourusername.github.io/your-repo/catalog.html`

## Local Testing

```bash
python build.py
# Open output/catalog.html in a browser
```
