#!/usr/bin/env python3
"""
build.py — Reads CSV from data/ and renders all HTML templates from templates/
into the output/ folder, fully self-contained with their CSS and JS.

TEMPLATE SYNTAX:
  In your HTML templates, wrap the repeating section (a card, list item, row, etc.)
  inside any element with the attribute: data-csv-repeat

  Inside that element, use {{column_name}} placeholders matching your CSV headers.

  You can also use {{column_name}} OUTSIDE of data-csv-repeat for single-value
  summary placeholders — these will be replaced with the value from the FIRST row.

  Special built-in placeholders (available everywhere):
    {{__total_rows__}}   — total number of data rows
    {{__generated_at__}} — timestamp of generation

EXAMPLE:
  CSV (data/products.csv):
    name,price,category
    Widget,9.99,Tools
    Gadget,19.99,Tech

  Template (templates/shop.html):
    <div class="grid" data-csv-repeat>
      <div class="card">
        <h3>{{name}}</h3>
        <p>${{price}}</p>
        <span>{{category}}</span>
      </div>
    </div>

  Output → the <div data-csv-repeat> is duplicated for each CSV row,
  with placeholders filled in.
"""

import csv
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path

# ── Config ──────────────────────────────────────────────────────────────
DATA_DIR = Path("data")
TEMPLATE_DIR = Path("templates")
OUTPUT_DIR = Path("output")
ASSETS_DIR = Path("assets")  # shared CSS/JS/images


def find_csv():
    """Find the single CSV file in data/."""
    csvs = list(DATA_DIR.glob("*.csv"))
    if not csvs:
        raise FileNotFoundError("No CSV found in data/ folder")
    if len(csvs) > 1:
        print(f"⚠  Multiple CSVs found, using: {csvs[0].name}")
    return csvs[0]


def read_csv(path):
    """Read CSV and return (headers, rows) where each row is a dict."""
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        rows = list(reader)
    # Normalize header keys: strip whitespace, lowercase for matching
    clean_headers = [h.strip() for h in headers]
    clean_rows = []
    for row in rows:
        clean = {}
        for orig, clean_h in zip(headers, clean_headers):
            clean[clean_h] = (row.get(orig) or "").strip()
        clean_rows.append(clean)
    return clean_headers, clean_rows


def _expand_repeats(html, headers, rows):
    """Find data-csv-repeat elements (handling nested same-name tags) and duplicate per row."""
    marker = "data-csv-repeat"
    while marker in html:
        start_match = re.search(r'<(\w+)\s[^>]*?' + marker + r'[^>]*>', html)
        if not start_match:
            break
        tag_name = start_match.group(1)
        open_tag = start_match.group(0)
        search_from = start_match.end()

        # Stack-based matching for nested same-name tags
        depth = 1
        pos = search_from
        open_pat = re.compile(r'<' + tag_name + r'[\s>/]')
        close_pat = re.compile(r'</' + tag_name + r'\s*>')
        while depth > 0 and pos < len(html):
            next_open = open_pat.search(html, pos)
            next_close = close_pat.search(html, pos)
            if not next_close:
                break
            if next_open and next_open.start() < next_close.start():
                depth += 1
                pos = next_open.end()
            else:
                depth -= 1
                if depth == 0:
                    inner = html[search_from:next_close.start()]
                    close_tag = next_close.group(0)
                    full_end = next_close.end()

                    clean_open = re.sub(r'\s*' + marker + r'\s*', ' ', open_tag)
                    fragments = []
                    for i, row in enumerate(rows):
                        rendered = inner
                        for col in headers:
                            rendered = rendered.replace("{{" + col + "}}", row.get(col, ""))
                        rendered = rendered.replace("{{__index__}}", str(i))
                        rendered = rendered.replace("{{__number__}}", str(i + 1))
                        fragments.append(clean_open + rendered + close_tag)

                    html = html[:start_match.start()] + "\n".join(fragments) + html[full_end:]
                else:
                    pos = next_close.end()
    return html


def render_template(html, headers, rows):
    """
    1. Find all data-csv-repeat blocks and duplicate them per row.
    2. Replace any remaining {{placeholders}} with first-row values.
    3. Replace built-in placeholders.
    """
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    builtins = {
        "__total_rows__": str(len(rows)),
        "__generated_at__": now,
    }

    # ── Step 1: Expand data-csv-repeat blocks ──
    html = _expand_repeats(html, headers, rows)

    # ── Step 2: Replace standalone placeholders with first row ──
    if rows:
        first = rows[0]
        for col in headers:
            html = html.replace("{{" + col + "}}", first.get(col, ""))

    # ── Step 3: Built-in placeholders ──
    for key, val in builtins.items():
        html = html.replace("{{" + key + "}}", val)

    return html


def build():
    print("━" * 50)
    print("  CSV → HTML Renderer")
    print("━" * 50)

    # Read CSV
    csv_path = find_csv()
    headers, rows = read_csv(csv_path)
    print(f"  📄 CSV:  {csv_path.name}  ({len(rows)} rows, {len(headers)} cols)")
    print(f"  📋 Columns: {', '.join(headers)}")

    # Find templates
    templates = list(TEMPLATE_DIR.glob("*.html"))
    if not templates:
        raise FileNotFoundError("No HTML templates found in templates/ folder")
    print(f"  🎨 Templates: {len(templates)} found")

    # Clean & create output dir
    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)
    OUTPUT_DIR.mkdir(parents=True)

    # Copy assets if they exist
    if ASSETS_DIR.exists():
        shutil.copytree(ASSETS_DIR, OUTPUT_DIR / "assets")
        print(f"  📁 Assets copied")

    # Render each template
    for tpl in templates:
        html = tpl.read_text(encoding="utf-8")
        rendered = render_template(html, headers, rows)
        out_path = OUTPUT_DIR / tpl.name
        out_path.write_text(rendered, encoding="utf-8")
        print(f"  ✅ {tpl.name} → output/{tpl.name}")

    print("━" * 50)
    print(f"  Done! {len(templates)} pages rendered to output/")
    print("━" * 50)


if __name__ == "__main__":
    build()
